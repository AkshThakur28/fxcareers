<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Failed</title>
</head>
<body>
    <h2>Payment Failed</h2>
    <p>Your payment failed. Please try again.</p>
</body>
</html>
